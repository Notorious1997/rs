package Player;

import Map.Locations.Location;
import Player.Equipment.Equipment;
import Player.Level.CombatLevel;
import Player.Level.TotalLevel;

public class Player {
	private static final Player instance = new Player("Notorious");
	private String name;
	
	private Location location;
	private CombatLevel combatLevel;
	private TotalLevel totalLevel;	
	private Inventory inv;
	private Equipment eq; 
	
	private Player(String type) {
		this.name = type;
		this.combatLevel = new CombatLevel();
		this.totalLevel = new TotalLevel();
		this.location = new Location();
		inv = new Inventory();
		eq = new Equipment();
	}
	
	public static Player getInstance(){
		return instance;
	}

	@Override
	public String toString() {
		return name + ", level: " + Player.getInstance().combatLevel.getCombatLevel() + ", Total level: " + Player.getInstance().totalLevel.getTotalLevel();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Location getLocation() {
		return location;
	}

	public void setLocation(Location location) {
		this.location = location;
	}

	public CombatLevel getCombatLevel() {
		return combatLevel;
	}

	public void setCombatLevel(CombatLevel combatLevel) {
		this.combatLevel = combatLevel;
	}

	public TotalLevel getTotalLevel() {
		return totalLevel;
	}

	public void setTotalLevel(TotalLevel totalLevel) {
		this.totalLevel = totalLevel;
	}

	public Inventory getInv() {
		return inv;
	}

	public void setInv(Inventory inv) {
		this.inv = inv;
	}

	public Equipment getEq() {
		return eq;
	}

	public void setEq(Equipment eq) {
		this.eq = eq;
	}
	
	
}

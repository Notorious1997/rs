package Player;

import java.util.HashMap;
import java.util.Map.Entry;

import Items.Item;

public class Inventory {
	public HashMap<String, Integer> inventory = new HashMap<>();
	public int filledSlots = 0;
	public int inventoryLength = 3;

	public void addItem(Item item) {
		if (inventory.containsKey(item.getName())) {
			inventory.replace(item.getName(), inventory.get(item.getName()) + item.getQuantity());
			System.out.println(item.getName() + " has been added up. New quantity: " + inventory.get(item.getName()));
		} else if (inventoryLength == filledSlots) {
			System.out.println("No inventory spaces left to add " + item.getName() + ".");
		} else {
			inventory.put(item.getName(), item.getQuantity());
			System.out.println(item.toString() + " has been added to your inventory.");
			filledSlots++;
		}
		System.out.println("Filled slots: " + filledSlots);

	}

	public void ShowInventory() {
		System.out.println("You have the following items in your inventory: ");
		for (Entry<String, Integer> entry : inventory.entrySet()) {
			System.out.println(entry.getKey() + ":" + entry.getValue().toString());
		}
	}

	public static void showInventory() {
		Player.getInstance().getInv().ShowInventory();
	}

}

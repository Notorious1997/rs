package Player.Equipment;

public class Cape {

}

package Player.Equipment;

public class Ring {

}

package Player.Equipment;

public class Boots {

}

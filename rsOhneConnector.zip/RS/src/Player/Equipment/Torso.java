package Player.Equipment;

public class Torso {

}

package Player.Equipment;

import Items.Item;
import Player.Player;

public class Equipment {
	
	Weapon weapon;

	public Weapon getWeapon() {
		return weapon;
	}

	public void setWeapon(Weapon weapon) {
		this.weapon = weapon;
	}
	
	public String toString(){
		return "The following items are equipped: " + getWeapon(); 
	}
	
	public static void showEquipment(){
		System.out.println(Player.getInstance().getEq().toString());
	}
	
	public void Equip(Item item) {
		Player.getInstance().getEq().setWeapon((Weapon) item);
	}

	
}

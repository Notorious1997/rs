package Player.Equipment;

public class Gloves {

}

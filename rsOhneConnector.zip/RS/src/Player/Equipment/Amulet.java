package Player.Equipment;

public class Amulet {

}

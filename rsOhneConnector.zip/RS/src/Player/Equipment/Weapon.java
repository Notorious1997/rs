package Player.Equipment;

import Items.Item;

public class Weapon extends Item{
	int attackDamage;
	

	public Weapon(int quantity, String name, int attackDamage) {
		super(quantity, name);
		this.attackDamage = attackDamage;
	}

	protected void useItem() {
		System.out.println("Equips Sword");
	}
	
	

	

}

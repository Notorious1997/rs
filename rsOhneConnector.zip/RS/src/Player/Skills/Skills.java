package Player.Skills;

import java.util.LinkedList;

public abstract class Skills {
	LinkedList<Skills> skills = new LinkedList<>();
	String name;
	int level;
	int experience;
	
	void increaseLevel(){
		level++;
	}
	
	void initializeSkills(){
		Woodcutting wc = new Woodcutting();
		skills.add(wc);
	}
	
	void showSkills(){
		for(Skills skill : skills){
			System.out.println(skill);
		}
	}
}

package Player.Skills;

public class Attack extends Skills {
	
}

package Player.Skills;

public class Woodcutting extends Skills {
	static int oakLogExperience = 5;

	// Testing Thread mechanism
	public static void chopTree() {

		Thread thread = new Thread("Woodcutting") {
			public void run() {
				System.out.println("Started to train: " + getName());
				for (int i = 0; i < 5; i++) {
					try {
						Thread.sleep(2000);
						System.out.println("Chops oak tree");
						System.out.println(oakLogExperience + " xp");
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				
			}
		};
		thread.start();
	}
}

package Player.Level;

public class TotalLevel extends Level {
	int totalLevel;

	public TotalLevel() {
		this.totalLevel = 31;
	}

	TotalLevel(int totalLevel) {
		this.totalLevel = totalLevel;
	}

	public int getTotalLevel() {
		return totalLevel;
	}

	@Override
	public void showLevel() {
		// TODO Auto-generated method stub

	}

	@Override
	void levelUp() {
		// TODO Auto-generated method stub
		
	}

}

package Player.Level;

public abstract class Level {
	int level;
	
	public void increaseLevel(){
		level++;
	}

	public int getLevel() {
		return level;
	}
	
	abstract void showLevel();
	
	abstract void levelUp();
}

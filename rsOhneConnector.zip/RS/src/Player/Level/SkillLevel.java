package Player.Level;

public class SkillLevel extends Level{
	int experience = 0;
	
	@Override
	void showLevel() {
		// TODO Auto-generated method stub
		
	}

	@Override
	void levelUp() {
		
	}
	
}
/*
	choptree -> xp
	xp -> woodcutting skill
	if xp over x -> levelup
	experience 


*/
package Player.Level;

import Player.Player;

public class CombatLevel extends Level {
	int combatLevel;

	public CombatLevel() {
		combatLevel = 3;
	}

	public int getCombatLevel() {
		return combatLevel;
	}

	@Override
	public void increaseLevel() {
		combatLevel++;
		System.out.println("Congratulations! Your new combat level is: " + combatLevel);
	}

	public static void showCombatLevel() {

	}

	@Override
	void showLevel() {
		System.out.println("Current combat level: " + Player.getInstance().getCombatLevel().getCombatLevel());
	}

	@Override
	void levelUp() {
		// TODO Auto-generated method stub
		
	}

}

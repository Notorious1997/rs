package Items;

import Player.Player;

public class Item {
	private String name;
	private int quantity;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public Item(String name){
		this.name = name;
		this.quantity = 1;
	}
	

	public Item(int quantity, String name) {
		this.name = name;
		this.quantity = quantity;
	}

	public static void spawnItem() {
		Item item = ItemFactory.generateRandomItem();
		Player.getInstance().getInv().addItem(item);

	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	@Override
	public String toString() {
		return quantity + "x " + name;
	}

}

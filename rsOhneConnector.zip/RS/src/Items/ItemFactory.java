package Items;

import java.sql.*;
import java.util.Random;

public class ItemFactory {

	public static Item generateRandomItem() {
		Item item = null;
		try {
			// Connect to database
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection(
					"jdbc:mysql://" + "127.0.0.1" + ":" + 3306 + "/" + "demodb"
							+ "?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=Europe/Berlin",
					"root", "");

			Statement stmt = con.createStatement();

			ResultSet numberOfItemsInDataBase = stmt.executeQuery("SELECT count(*) FROM items;");
			numberOfItemsInDataBase.next();
			int id = new Random().nextInt(numberOfItemsInDataBase.getInt(1));
			
			// spawn random item from database
			ResultSet itemsInDataBase = stmt.executeQuery("select * from items order by id limit 1 offset " + id);
			if (itemsInDataBase.next()) {
				item = new Item(itemsInDataBase.getString(2));

			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return item;
	}

}

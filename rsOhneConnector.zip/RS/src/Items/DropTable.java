package Items;

import java.util.ArrayList;

public class DropTable {
	private ArrayList<Item> drops = new ArrayList<>();

	public ArrayList<Item> getDrops() {
		return drops;
	}
	
	
}

package Map.Locations;

public class Location {
	String name;
	
	public Location(String name) {
		this.name = name;
	}


	public Location() {
		name = "Lumbridge";
	}


	public String getName() {
		return name;
	}


}

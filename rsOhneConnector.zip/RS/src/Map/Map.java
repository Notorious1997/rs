package Map;

import java.util.ArrayList;

import Map.Locations.Location;
import Player.Player;

public class Map {
	static ArrayList<Location> locations = new ArrayList<>();

	public Map(ArrayList<Location> locations) {
		Map.locations = locations;
	}

	public static Map initializeMap() {
		ArrayList<Location> locations = new ArrayList<>();
		Map map = new Map(locations);

		Location lumbridge = new Location("Lumbridge");
		Location varrock = new Location("Varrock");

		locations.add(lumbridge);
		locations.add(varrock);
		
		locations.add(new Location(("Falador")));

		return map;
	}

	public static void showLocations() {
		for (Location loc : locations) {
			System.out.println(loc.getName());
		}
	}

	public static void travel() {
		System.out.println("Where would you like to travel?");

		showLocations();
	}

	public static void locate() {
		System.out.println("Your character is in: " + Player.getInstance().getLocation().getName());
	}

}

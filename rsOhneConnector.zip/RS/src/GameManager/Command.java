package GameManager;

public interface Command {
	void execute();
}

package GameManager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

import Items.Item;
import Items.ItemFactory;
import Map.Map;
import Player.Inventory;
import Player.Player;
import Player.Equipment.Equipment;
import Player.Equipment.Weapon;
import Player.Level.CombatLevel;
import Player.Skills.Woodcutting;

public class MyCommand implements Command {
	// HashMap<String, HashMap<String, Command>> commands = new HashMap<>();

	static void initializeCommands() {

	}

	static void showCommands() {
		ArrayList<String> commands = new ArrayList<>();
		ArrayList<String> adminCommands = new ArrayList<>();
		
		// TODO: Describe all commands from HashMap
		commands.add("'commands' : Lists your commands.");
		commands.add("'locate': Locates your character.");
		commands.add("'inventory' : Opens up your inventory.");
		commands.add("'equipment' : Displays your equipment.");
		commands.add("'travel' : Allows you to travel anywhere.");
		commands.add("'combatlevel' : Shows your current combat level.");
		commands.add("'totallevel' : Shows your current total level.");
		commands.add("'logout' : Logs out your character.");

		adminCommands.add("'spawnitem': Spawns a random item in your inventory.");
		adminCommands.add("'increaselevel' : Increases your combat level by 1.");
		System.out.println("User commands: ");
		for (String cmd : commands) {
			System.out.println(cmd);
		}

		System.out.println("--------------------------------------------- \nAdmin commands: ");
		for (String cmd : adminCommands) {
			System.out.println(cmd);
		}
	}

	@Override
	public void execute() {

	}

	static void useCommands() {
		HashMap<String, Command> commands = new HashMap<>();
		commands.put("locate", () -> Map.locate());
		commands.put("commands", () -> showCommands());
		commands.put("inventory", () -> Inventory.showInventory());
		commands.put("spawnitem", () -> Item.spawnItem());
		commands.put("equipment", () -> Equipment.showEquipment());
		commands.put("combatlevel", () -> CombatLevel.showCombatLevel());
		commands.put("totallevel", () -> Player.getInstance().getTotalLevel().showLevel());
		commands.put("increasecombatlevel", () -> Player.getInstance().getCombatLevel().increaseLevel());
		commands.put("travel", () -> Map.travel());
		commands.put("wc", () -> Woodcutting.chopTree());
		commands.put("equip", () -> Player.getInstance().getEq().setWeapon((Weapon) ItemFactory.generateRandomItem()));
		commands.put("logout", () -> System.exit(0));

		String input = "";
		Scanner sc = new Scanner(System.in);
		while (!input.equals("logout")) {
			input = sc.next();
			if (commands.containsKey(input)) {
				Command command = commands.get(input);
				command.execute();
			}

		}
		sc.close();
	}
}

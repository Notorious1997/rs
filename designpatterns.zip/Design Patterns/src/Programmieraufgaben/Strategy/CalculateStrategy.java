package Programmieraufgaben.Strategy;

public interface CalculateStrategy {
	int calculate(int a, int b);
}

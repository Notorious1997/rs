package Programmieraufgaben.Strategy;

public class Test {

	public static void main(String[] args) {
		CalculateStrategy csAdd = (a, b) -> a + b;
		System.out.println(csAdd.calculate(1, 2));
		
		CalculateStrategy csMultiply = (a, b) -> a * b;
		System.out.println(csMultiply.calculate(2, 6));
	}

}

package Programmieraufgaben.FactoryMethod;

public class WowItemFactory extends ItemFactory {

	@Override
	public Item createItem(int id) {
		Item item = null;
		if(id == 1){
			item = new Shield("Shield", 1, 30);
		} else if(id == 2){
			item = new Hammer("Kriegshammer", 2, 40);
		} else {
			System.out.println("Fehler");
		}
		return item;
	}

}

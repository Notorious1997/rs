package Programmieraufgaben.FactoryMethod;

public class Test {

	public static void main(String[] args) {
		ItemFactory produceItems = new WowItemFactory();
		produceItems.generateRandomItem().useItem();
	}

}

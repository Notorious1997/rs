package Programmieraufgaben.FactoryMethod;

public class Hammer extends Item {
	

	public int attackValue;

	
	public Hammer(String name, int id, int attackValue) {
		super(name, id);	
		this.attackValue = attackValue;
	}

	@Override
	public void useItem() {
		System.out.println("Uses Hammer");
	}

}

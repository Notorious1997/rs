package Programmieraufgaben.FactoryMethod;

public class Shield extends Item {
	int defenseValue;
	
	public Shield(String name, int id, int defenseValue) {
		super(name, id);
		this.defenseValue = defenseValue;
	}

	@Override
	public void useItem() {
		System.out.println("Uses shield");
	}
	
	

}

package Programmieraufgaben.FactoryMethod;

public abstract class Item {
	String name;
	final int id;
	
	public abstract void useItem();

	public Item(String name, int id) {
		this.name = name;
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getId() {
		return id;
	}

}

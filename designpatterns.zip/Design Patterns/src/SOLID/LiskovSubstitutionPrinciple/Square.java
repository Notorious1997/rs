package SOLID.LiskovSubstitutionPrinciple;

public class Square extends Rectangle {

	public Square(double size) {
		super(size, size);
	}
	
	@Override
	public void setWidth(double width){
		super.setHeight(width);
		super.setHeight(width);
	}
	
	@Override
	public void setHeight(double height){
		super.setHeight(height);
		super.setWidth(height);
	}
	
	
	
}

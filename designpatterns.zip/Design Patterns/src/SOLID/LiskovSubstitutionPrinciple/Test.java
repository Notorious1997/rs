package SOLID.LiskovSubstitutionPrinciple;

public class Test {
	public static void main(String[] args) {
		/*Rectangle rec = new Rectangle(4,3);
		doSomething(rec);
		
		Square s1 = new Square(3);
		doSomething(s1);
		*/
		
		Rectangle rec = new Rectangle(5, 10);
		doubleValues(rec);
		
		Square s1 = new Square(6.0);
		doubleValues(s1);
	}
	
	public static void doSomething(Rectangle rec){
		double height = rec.getHeight();
		rec.setWidth(20);
		System.out.println("Erwarteter Fl�cheninhalt: " + 20 * height);
		System.out.println("Tats�chlicher Fl�cheninhalt: " + rec.calcArea());
	}
	
	public static void doubleValues(Rectangle rec){
		System.out.println("Current Values are: \n" + "Rec Width: " + rec.width + "\n" + "Rec Height: " + rec.height);
		rec.setHeight(rec.getHeight() * 2);
		// rec.setWidth(rec.getWidth() * 2);
		System.out.println("New Values are: \n" + "Rec Width: " + rec.width + "\n" + "Rec Height: " + rec.height);
	}
}

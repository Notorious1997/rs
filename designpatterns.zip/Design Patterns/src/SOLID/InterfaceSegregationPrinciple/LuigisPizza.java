package SOLID.InterfaceSegregationPrinciple;

public class LuigisPizza implements Payment, Order {

	@Override
	public void TakeOrderByPhone() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void PayByCash() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void PayByCreditcard() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void PayBySmartphone() {
		// TODO Auto-generated method stub
		
	}

}

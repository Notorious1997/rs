package SOLID.InterfaceSegregationPrinciple;

public interface Payment {
	public void PayByCash();
	public void PayByCreditcard();
	public void PayBySmartphone();
}

package SOLID.InterfaceSegregationPrinciple;

public interface RatingService {
	public void RateMyRestaurant();
}

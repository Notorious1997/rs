package SOLID.InterfaceSegregationPrinciple;

public interface Order {
	public void TakeOrderByPhone();
}

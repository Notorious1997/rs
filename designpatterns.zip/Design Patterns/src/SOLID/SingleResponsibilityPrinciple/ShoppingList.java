package SOLID.SingleResponsibilityPrinciple;

import java.util.ArrayList;

public class ShoppingList {
	private ArrayList<String> entries = new ArrayList<>();
	

	public ArrayList<String> getEntries() {
		return entries;
	}

	public void setEntries(ArrayList<String> entries) {
		this.entries = entries;
	}

	public void addEntry(String name) {
		entries.add(name);
	}

	public void removeItem(String name) {
		entries.remove(name);
	}

	@Override
	public String toString() {
		String output = "Shopping list: \n";
		for (String entry : entries) {
			output += entry;
			output += "\n";

		}
		return output;
	}

}

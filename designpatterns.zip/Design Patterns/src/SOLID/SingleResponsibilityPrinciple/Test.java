package SOLID.SingleResponsibilityPrinciple;

import java.io.File;

public class Test {
	public static void main(String[] args) {
		ShoppingList list = new ShoppingList();
		
		list.addEntry("2 bananas");
		list.addEntry("5 apples");
		
		System.out.println(list.toString());
		
		SaveListAsFile file = new SaveListAsFile();
		file.saveFile(list.getEntries(), new File("shoppinglist.txt"));
	}
}

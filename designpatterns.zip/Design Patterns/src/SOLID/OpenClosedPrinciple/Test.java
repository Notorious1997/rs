package SOLID.OpenClosedPrinciple;

import java.util.ArrayList;

public class Test {
	public static void main(String[] args) {
		Rectangle rec = new Rectangle(3, 5);
		Triangle tri = new Triangle(1,4);
		
		Circle cir = new Circle(3);
		
		ArrayList<Shape> shapes = new ArrayList<>();
		shapes.add(rec);
		shapes.add(tri);
		shapes.add(cir);
		
		
		CalculateArea ca = new CalculateArea();
		
		System.out.println(ca.calculateArea(shapes));
	}
}

package SOLID.OpenClosedPrinciple;

public class Triangle extends Shape {
	private double height;
	private double length;

	public double getHeight() {
		return height;
	}

	public void setHeight(double height) {
		this.height = height;
	}

	public double getLength() {
		return length;
	}

	public void setLength(double length) {
		this.length = length;
	}

	public Triangle(double height, double length) {
		this.height = height;
		this.length = length;
	}

	@Override
	public double calcArea() {
		return height * length / 2;
	}

}

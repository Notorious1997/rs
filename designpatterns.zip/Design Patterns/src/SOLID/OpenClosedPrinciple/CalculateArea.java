package SOLID.OpenClosedPrinciple;

import java.util.ArrayList;

public class CalculateArea {
	public double calculateArea(ArrayList<Shape> shapes){
		double area = 0;
		
		for(Shape shape : shapes){
			area += shape.calcArea();
		}
		return area;
	}
	
	// Warum ist shape.calcArea hier verf�gbar aber nicht in der Testklasse?
}

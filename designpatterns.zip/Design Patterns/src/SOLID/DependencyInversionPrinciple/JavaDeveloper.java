package SOLID.DependencyInversionPrinciple;

public class JavaDeveloper implements Developer {

	@Override
	public void Develop() {
		System.out.println("I write java-code");
	}
}

package SOLID.DependencyInversionPrinciple;

public interface Developer {
	public void Develop();
}

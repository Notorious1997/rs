package SOLID.DependencyInversionPrinciple;

public class JavaScriptDeveloper implements Developer {

	@Override
	public void Develop() {
		System.out.println("I write javascript-code");
		
	}
}

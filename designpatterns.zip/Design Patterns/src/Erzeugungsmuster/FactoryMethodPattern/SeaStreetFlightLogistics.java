package Erzeugungsmuster.FactoryMethodPattern;

public class SeaStreetFlightLogistics extends Logistics {

	@Override
	protected Transport transportFactory(String transportType) {
		Transport transport = null;

		if (transportType.equals("Sea")) {
			transport = new SeaTransport();
		} else if (transport.equals("Street")) {
			transport = new StreetTransport();
		} else if (transport.equals("Flight")) {
			transport = new FlightTransport();
		} else {
			System.out.println("Ung�ltiger Transporttyp");
		}
		return transport;
	}

}

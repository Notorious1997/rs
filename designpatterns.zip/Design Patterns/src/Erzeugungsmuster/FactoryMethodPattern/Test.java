package Erzeugungsmuster.FactoryMethodPattern;

public class Test {

	public static void main(String[] args) {
		Logistics logisticsSoftware = new SeaStreetFlightLogistics();
		Transport seaTransport = logisticsSoftware.manageTransportForCustomer("Sea");
	}

}

package Erzeugungsmuster.FactoryMethodPattern;

public class FlightTransport extends Transport {

	@Override
	public void transportProducts() {
		System.out.println("Die Produkte werden �ber den Flugweg transportiert");		
	}

}

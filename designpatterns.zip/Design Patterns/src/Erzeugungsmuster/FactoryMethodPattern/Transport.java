package Erzeugungsmuster.FactoryMethodPattern;

public abstract class Transport {

	public void collectProductsFromCustomer() {
		System.out.println("Die Produkte wurden vom Kunden abgeholt");
	}

	public abstract void transportProducts();
}

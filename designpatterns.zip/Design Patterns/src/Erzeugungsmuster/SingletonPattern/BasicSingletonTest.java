package Erzeugungsmuster.SingletonPattern;

public class BasicSingletonTest {

	public static void main(String[] args) {
		BasicSingleton obj1 = BasicSingleton.getInstance();
		
		BasicSingleton obj2 = BasicSingleton.getInstance();
	}

}

package Erzeugungsmuster.SingletonPattern;

public class LazySingleton {
	private static LazySingleton instance;
	
	private LazySingleton(){
		System.out.println("Instanz wurde erstellt");
	}

	public static LazySingleton getInstance(){
		if(instance == null){
			instance = new LazySingleton();
		}
		return instance;
	}

}

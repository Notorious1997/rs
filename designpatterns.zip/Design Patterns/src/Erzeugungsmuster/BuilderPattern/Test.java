package Erzeugungsmuster.BuilderPattern;

public class Test {

	public static void main(String[] args) {
		HouseBuilder whb = new WoodHouseBuilder();
		// HouseBuilder shb = new StoneHouseBuilder();
		
		CivilEngineer engineer = new CivilEngineer(whb);
		engineer.constructHouse();
		
		House house = engineer.getHouse();
		System.out.println(house);
	}

}

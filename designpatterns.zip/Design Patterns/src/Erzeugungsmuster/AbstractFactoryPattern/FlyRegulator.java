package Erzeugungsmuster.AbstractFactoryPattern;

public class FlyRegulator extends Regulator {
	
	public FlyRegulator(){
		System.out.println("Der FlyRegulator wurde erfolgreich erstellt.");
	}

	@Override
	public void increaseVoltage() {
		System.out.println("Die Spannung des FlyRegulators wurde um 30V erh�ht.");
	}
}	

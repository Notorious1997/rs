package Erzeugungsmuster.AbstractFactoryPattern;

public class QuadroEngine extends Engine {

	public QuadroEngine(){
		System.out.println("Die Quadroengine wurde erfolgreich erzeugt!");
	}
	
	@Override
	public void revCounter() {
		System.out.println("Die aktuelle Drehzahl der QuadroEngine betr�gt 300 Umdrehungen/Minute");
	}
	
}

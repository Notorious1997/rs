package Erzeugungsmuster.AbstractFactoryPattern;

public class Test {

	public static void main(String[] args) {
		FlyFactory ff = new FlyFactory();
		ControllerBoard controller = new ControllerBoard(ff);
		
		
	}

}

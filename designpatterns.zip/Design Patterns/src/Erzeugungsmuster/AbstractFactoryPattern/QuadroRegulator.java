package Erzeugungsmuster.AbstractFactoryPattern;

public class QuadroRegulator extends Regulator {

	public QuadroRegulator(){
		System.out.println("Der QuadroRegulator wurde erfolgreich erstellt");
	}
	
	@Override
	public void increaseVoltage() {
		System.out.println("Die Spannung des QuadroRegulators wurde um 10V erh�ht");
	}
	
}

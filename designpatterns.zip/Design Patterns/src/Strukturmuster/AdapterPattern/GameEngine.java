package Strukturmuster.AdapterPattern;

public class GameEngine {
	public static void main(String[] args) {

		EnemyObject orc1 = new EnemyObjectOrc();
		
		orc1.Attack();
		orc1.SayHello();
		
		Wizard wizard = new Wizard();
		wizard.SayHelloWizard();
	
	}

}

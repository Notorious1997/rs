package Strukturmuster.AdapterPattern;

public class AdapterWizard implements EnemyObject {
	private Wizard wizard;
	
	public AdapterWizard(Wizard wizard){
		this.wizard = wizard;
	}

	@Override
	public void Attack() {
		wizard.AttackWizard();
	}

	@Override
	public void SayHello() {
		wizard.SayHelloWizard();
	}

	@Override
	public void Sleep() {
		wizard.SleepWizard();
		
	}
	
}

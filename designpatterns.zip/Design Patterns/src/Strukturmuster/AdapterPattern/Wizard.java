package Strukturmuster.AdapterPattern;

public class Wizard {
	public String name;
	public int health;
	
	public void AttackWizard(){
		System.out.println("Wizard Attack");
		
	}
	
	public void SleepWizard(){
		System.out.println("Wizard sleep");
		
	}
	
	public void SayHelloWizard(){
		System.out.println("Wizard Hello");
	}
}

package Strukturmuster.AdapterPattern;

public class EnemyObjectOrc implements EnemyObject{
	private String name;
	private int health;
	
	@Override
	public void Attack() {
		System.out.println("Orc Attack");
	}

	@Override
	public void SayHello() {

		System.out.println("Orc Hello");
		// TODO Auto-generated method stub
		
	}

	@Override
	public void Sleep() {
		System.out.println("Orc Sleep");
		// TODO Auto-generated method stub
		
	}

}

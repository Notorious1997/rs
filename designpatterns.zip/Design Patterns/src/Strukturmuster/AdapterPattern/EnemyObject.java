package Strukturmuster.AdapterPattern;

public interface EnemyObject {
	public void Attack();
	public void SayHello();
	public void Sleep();
}

package Strukturmuster.BridgePattern;

public class GreenRectangle implements DrawAPI{

	@Override
	public void draw(int x, int y, int length, int width) {
		System.out.println("Das gr�ne Rechteck wurde erstellt");
	}
	
}

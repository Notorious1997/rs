package Strukturmuster.BridgePattern;

public interface DrawAPI {
	public void draw(int x, int y, int length, int width);
}

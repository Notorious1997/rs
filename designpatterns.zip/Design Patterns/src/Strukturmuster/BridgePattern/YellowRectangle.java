package Strukturmuster.BridgePattern;

public class YellowRectangle implements DrawAPI {

	@Override
	public void draw(int x, int y, int length, int width) {
		System.out.println("Das gelbe Rechteck wurde erzeugt");
	}

}

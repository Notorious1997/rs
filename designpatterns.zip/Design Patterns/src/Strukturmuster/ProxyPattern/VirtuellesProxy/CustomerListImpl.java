package Strukturmuster.ProxyPattern.VirtuellesProxy;

import java.util.ArrayList;
import java.util.List;

public class CustomerListImpl implements CustomerList {

	@Override
	public List<Customer> getCustomerList() {
		List<Customer> customerList = new ArrayList<Customer>();
		customerList.add(new Customer("Azad", "Teststra�e", true));
		customerList.add(new Customer("Azad2", "Teststra�e2", false));
		customerList.add(new Customer("Azad3", "Teststra�e3", true));
		customerList.add(new Customer("Azad4", "Teststra�e3", true));
		customerList.add(new Customer("Azad5", "Teststra�e4", true));
		System.out.println("Datenbankabfrage war erfolgreich");
		return customerList;
	}

}

package Strukturmuster.ProxyPattern.VirtuellesProxy;

public class Customer {
	private String name;
	private String adress;
	private boolean bonusCard;

	Customer(String name, String adress, boolean bonusCard) {
		this.name = name;
		this.adress = adress;
		this.bonusCard = bonusCard;
	}

	@Override
	public String toString() {
		return "Customer [name=" + name + ", adress=" + adress + ", bonusCard=" + bonusCard + "]";
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAdress() {
		return adress;
	}

	public void setAdress(String adress) {
		this.adress = adress;
	}

	public boolean isBonusCard() {
		return bonusCard;
	}

	public void setBonusCard(boolean bonusCard) {
		this.bonusCard = bonusCard;
	}

}

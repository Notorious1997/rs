package Strukturmuster.ProxyPattern.VirtuellesProxy;

public class Company {
	private String name;
	private String adress;
	private CustomerList customerList;

	public Company(String name, String adress, CustomerList customerList) {
		this.name = name;
		this.adress = adress;
		this.customerList = customerList;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAdress() {
		return adress;
	}

	public void setAdress(String adress) {
		this.adress = adress;
	}

	public CustomerList getCustomerList() {
		return customerList;
	}

	public void setCustomerList(CustomerList customerList) {
		this.customerList = customerList;
	}


}

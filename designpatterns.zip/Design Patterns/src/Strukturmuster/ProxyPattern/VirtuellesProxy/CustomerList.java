package Strukturmuster.ProxyPattern.VirtuellesProxy;

import java.util.List;

public interface CustomerList {
	public List<Customer> getCustomerList();
	
	
}

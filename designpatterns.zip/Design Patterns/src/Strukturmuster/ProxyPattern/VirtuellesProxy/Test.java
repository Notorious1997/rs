package Strukturmuster.ProxyPattern.VirtuellesProxy;

import java.util.List;

public class Test {

	public static void main(String[] args) {
		CustomerList list1 = new CustomerListProxyImpl();
		
		Company company1 = new Company("Testcompany", "Testlocation", list1);
		
		System.out.println("Company name: " + company1.getName());
		
		list1 = company1.getCustomerList();
		List<Customer> cusList = list1.getCustomerList(); 
		for (Customer customer : cusList) {
			System.out.println(customer);
		}
	}

}

package Strukturmuster.ProxyPattern;

public class Test {

	public static void main(String[] args) {
		DownloadProduct javaEbook = new DownloadProduct("Java E-Book");
		Customer azad = new Customer("Azad");
		
		DownloadProductProxy patternEbook = new DownloadProductProxy("Design Patterns");
		patternEbook.download(azad);
		patternEbook.download(azad);
		patternEbook.download(azad);
		patternEbook.download(azad);
	}

}

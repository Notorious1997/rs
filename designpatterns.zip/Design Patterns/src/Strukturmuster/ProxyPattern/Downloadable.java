package Strukturmuster.ProxyPattern;

public interface Downloadable {
	public void download(Customer customer);
}

package Strukturmuster.Flyweight;

public class Test {

	public static void main(String[] args) {
		Tree tree1 = TreeFactory.getTree(TreeType.TANNE);
		tree1.drawTree(10, 10, 30);
		
		Tree tree2 = TreeFactory.getTree(TreeType.TANNE);
		tree2.drawTree(5, 5, 15);
		
		Tree tree3 = TreeFactory.getTree(TreeType.BIRKE);
		tree3.drawTree(10, 10, 30);
		
		Tree tree4 = TreeFactory.getTree(TreeType.BIRKE);
		tree4.drawTree(5, 5, 15);
		
	}

}

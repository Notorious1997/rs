package Strukturmuster.Flyweight;

import java.awt.Color;

public class Tanne implements Tree {
	private Color color;
	private TreeType treeType;
	
	public Tanne(){
		color = Color.GREEN;
		this.treeType = treeType.TANNE;
	}

	@Override
	public Color getColor() {
		return color;
	}

	@Override
	public TreeType getTreeType() {
		return treeType;
	}

	@Override
	public void drawTree(int x, int y, int height) {
		System.out.println("Tanne wurde an Position(" + x + "/" + y + ") mit einer H�he von " + height + "gezeichnet");
	}
	
	
}

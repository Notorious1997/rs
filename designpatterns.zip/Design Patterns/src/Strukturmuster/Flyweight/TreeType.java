package Strukturmuster.Flyweight;

public enum TreeType {
	TANNE,
	BIRKE
}

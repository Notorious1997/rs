package Strukturmuster.CompositePattern;

public class Test {

	public static void main(String[] args) {
		Directory videoCourse = new Directory("Videcourse");
		
		File courseScript = new File("Coursescript", "Test");
		Directory courseVideos = new Directory("Coursevideo");
		
		videoCourse.add(courseScript);
		videoCourse.add(courseVideos);
		
		Directory module1 = new Directory("Module 1");
		Directory module2 = new Directory("Module 2");
		
		courseVideos.add(module1);
		courseVideos.add(module2);
		
		File f1 = new File("Intro", "Azad");
		File f2 = new File("Installation", "Yekta");
		File f3 = new File("Variables", "Berfin");
		module1.add(f1);
		module2.add(f2);
		module2.add(f3);
		
		videoCourse.print("");
	}

}

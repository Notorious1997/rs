package Strukturmuster.DecoratorPattern;

public class AddOnTouchBar extends MacBookAddOn{

	
	public AddOnTouchBar(MacBook macBook) {
		super(macBook);
	}

	@Override
	public String getDescription() {
		return "TEST" + macBook.getDescription() + ", along with TouchBar";
	}

	@Override
	public double getPrice() {
		return macBook.getPrice() + 400.00;
	}

	@Override
	public void increaseVolume() {
		System.out.println("Increased volume of MacBookAir with TouchBar");
	}
	
}

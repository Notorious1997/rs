package Strukturmuster.DecoratorPattern;

public interface MacBook {
	public String getDescription();
	
	public double getPrice();
	
	public void increaseVolume();
}

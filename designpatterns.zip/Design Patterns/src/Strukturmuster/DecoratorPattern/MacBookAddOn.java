package Strukturmuster.DecoratorPattern;

public abstract class MacBookAddOn implements MacBook{
	protected MacBook macBook;
	
	public MacBookAddOn(MacBook macBook){
		this.macBook = macBook;
	}
}

package Strukturmuster.DecoratorPattern;

public class MacBookAir implements MacBook{

	@Override
	public String getDescription() {
		return "MacBookAir";
	}

	@Override
	public double getPrice() {
		return 999.99;
	}

	@Override
	public void increaseVolume() {
		System.out.println("Increased volume of MacBookAir");
	}

}

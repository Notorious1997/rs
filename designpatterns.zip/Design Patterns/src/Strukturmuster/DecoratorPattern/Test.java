package Strukturmuster.DecoratorPattern;

public class Test {

	public static void main(String[] args) {
		MacBookPro pc1 = new MacBookPro();
		/*
		pc1.increaseVolume();
		System.out.println(pc1.getPrice());
		System.out.println(pc1.getDescription());
		System.out.println("-------------------");
		AddOnTouchBar macBookWithTouchBar = new AddOnTouchBar(pc1);
		
		macBookWithTouchBar.increaseVolume();
		System.out.println(macBookWithTouchBar.getDescription());
		System.out.println(macBookWithTouchBar.getPrice());
		
		*/
		
		
	}

}

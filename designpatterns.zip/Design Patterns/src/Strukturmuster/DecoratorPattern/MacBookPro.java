package Strukturmuster.DecoratorPattern;

public class MacBookPro implements MacBook {

	@Override
	public String getDescription() {
		return "MacBookPro TEST";
	}

	@Override
	public double getPrice() {
		return 1399.99;
	}

	@Override
	public void increaseVolume() {
		System.out.println("Increased volume of MacBookPro");
	}

}

package Strukturmuster.Facade;

public class AirportSystem {
	public void checkLuggage(){
		System.out.println("Das Gep�ck wird ausgegeben");
	}
	
	public void transportToAirplane(){
		System.out.println("Das Gep�ck wird zum richtigen Flugzeug transportiert");
	}
}

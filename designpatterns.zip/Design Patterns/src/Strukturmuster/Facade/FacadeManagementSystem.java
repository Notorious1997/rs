package Strukturmuster.Facade;

public class FacadeManagementSystem {
	private AirportSystem airport;
	private Airplane airplane;
	private LocalLogisticsCompany llc;
	private Hotel hotel; 
	
	FacadeManagementSystem(){
		this.airport = new AirportSystem();
		this.airplane = new Airplane();
		this.llc = new LocalLogisticsCompany();
		this.hotel = new Hotel();
	}
	
	public void sendLuggage(){
		airport.checkLuggage();
		airport.transportToAirplane();
		
		airplane.putLuggageToPlane();
		airplane.takeLuggageOut();
		
		llc.putLuggageToTruck();
		llc.transportHotel();
		
		hotel.transportLuggageToGuest();
	}
}

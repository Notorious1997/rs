package Strukturmuster.Facade;

public class Airplane {
	public void putLuggageToPlane(){
		System.out.println("Das Gep�ck wird in das Flugzeug eingeladen");
	}
	
	public void takeLuggageOut(){
		System.out.println("Das Gep�ck wird aus dem Flugzeug ausgeladen");
	}
}

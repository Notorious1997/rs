package Strukturmuster.Facade;

public class Test {

	public static void main(String[] args) {
		FacadeManagementSystem manager = new FacadeManagementSystem();
		manager.sendLuggage();
	}

}

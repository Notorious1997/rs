package Strukturmuster.Facade;

public class Hotel {
	public void transportLuggageToGuest(){
		System.out.println("Das Gep�ck wird zum Gast gebracht.");
	}
}

package Strukturmuster.Facade;

public class LocalLogisticsCompany {
	public void transportHotel() {
		System.out.println("Das Gep�ck wird in den LKW eingeladen...");
	}
	
	public void putLuggageToTruck(){
		System.out.println("Das Gep�ck wird zum Hotel transportiert...");
	}
}

package Verhaltensmuster.Memento;

public class FitnessPlan {
	String type;

	public FitnessPlan(String type) {
		this.type = type;
	}
	
	public void changeTraining(String type){
		this.type = type;
		System.out.println(this.toString());
		
	}
	
	public Memento save(){
		System.out.println("State successfully saved");
		return new Memento(this.type);
	}

	public void restore(Memento memento){
		this.type = memento.getType();
	}
	
	@Override
	public String toString() {
		return "FitnessPlan [type=" + type + "]";
	}
	
	
	
	
}

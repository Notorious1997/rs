package Verhaltensmuster.Memento;

public class Memento {
	String type;

	public Memento(String type) {
		super();
		this.type = type;
	}

	public String getType() {
		return type;
	}
	
	
}

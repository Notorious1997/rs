package Verhaltensmuster.Memento;

public class Test {

	public static void main(String[] args) {
		Caretaker caretaker = new Caretaker();
		
		FitnessPlan plan = new FitnessPlan("Ausdauer");
		System.out.println(plan);
		
		caretaker.saveState(plan);
		plan.changeTraining("Kraft");
		

		caretaker.saveState(plan);
		plan.changeTraining("Gemischt");

		caretaker.saveState(plan);
		
		caretaker.restoreState(plan, 1);
		System.out.println(plan);
	}

}

package Verhaltensmuster.Memento;

import java.util.ArrayList;

public class Caretaker {
	private ArrayList<Memento> mementos = new ArrayList<>();

	public Caretaker() {
		this.mementos = new ArrayList<Memento>();
	}

	public void saveState(FitnessPlan plan) {
		mementos.add(plan.save());
	}

	public void restoreState(FitnessPlan plan, int index) {
		plan.restore(mementos.get(index));
	}
}

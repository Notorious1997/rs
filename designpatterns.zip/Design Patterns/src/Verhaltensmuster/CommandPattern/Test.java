package Verhaltensmuster.CommandPattern;

public class Test {

	public static void main(String[] args) {
		BankAccount myAccount = new BankAccount(1000);
		
		BankTransactionCommand command1 = new DepositCommand(myAccount, 100);
		BankTransactionCommand command2 = new WithdrawCommand(myAccount, 200);
		
		CashMachine machine = new CashMachine();
	
		command1.execute();
	}

}

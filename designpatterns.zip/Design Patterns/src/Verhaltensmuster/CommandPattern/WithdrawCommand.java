package Verhaltensmuster.CommandPattern;

public class WithdrawCommand implements BankTransactionCommand {
	BankAccount account;
	private int amount;
	
	WithdrawCommand(BankAccount account, int amount) {
		this.account = account;
		this.amount = amount;
	}

	@Override
	public void execute() {
		account.withdraw(amount);
	}

	@Override
	public void undo() {
		account.setBalance(account.getBalance() + amount);
		System.out.println("Reversed transaction. New balance is: " + account.getBalance());
	}
}

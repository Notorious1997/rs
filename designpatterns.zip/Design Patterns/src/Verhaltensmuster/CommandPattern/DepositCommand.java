package Verhaltensmuster.CommandPattern;

public class DepositCommand implements BankTransactionCommand {
	BankAccount account;
	private int amount;
	
	DepositCommand(BankAccount account, int amount) {
		this.account = account;
		this.amount = amount;
	}

	@Override
	public void execute() {
		account.deposit(amount);
	}

	@Override
	public void undo() {
		account.setBalance(account.getBalance() - amount);
		System.out.println("Reversed transaction. New balance is: " + account.getBalance());
	}

}

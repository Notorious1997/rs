package Verhaltensmuster.CommandPattern;

public class BankAccount {
	int balance;

	BankAccount(int amount) {
		balance = amount;
		System.out.println("Opened new bankaccount with " + balance + "�");
	}
	
	@Override
	public String toString() {
		return "BankAccount [balance=" + balance + "]";
	}

	void deposit(int amount){
		balance += amount;
		System.out.println("Succesfully deposited " + amount + "�. Your new balance is: " + balance);
	}
	
	void withdraw(int amount){
		balance -= amount;
		System.out.println("Succesfully withdrawed " + amount + "�. Your new balance is: " + balance);
	}

	public int getBalance() {
		return balance;
	}

	public void setBalance(int balance) {
		this.balance = balance;
	}

}

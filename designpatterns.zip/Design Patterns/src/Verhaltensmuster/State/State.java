package Verhaltensmuster.State;

public abstract class State {
	public abstract void blink();
	public abstract void change();
}

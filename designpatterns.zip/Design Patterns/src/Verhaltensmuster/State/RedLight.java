package Verhaltensmuster.State;

public class RedLight extends State{
	private Light light;

	@Override
	public void blink() {
		System.out.println("Red light");
	}

	public RedLight(Light light) {

		this.light = light;
	}

	@Override
	public void change() {
		System.out.println("Changes to green light");
	}

}

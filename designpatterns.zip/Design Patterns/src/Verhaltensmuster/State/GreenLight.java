package Verhaltensmuster.State;

public class GreenLight extends State {
	private Light light;

	public GreenLight(Light light) {
		this.light = light;
	}

	@Override
	public void blink() {
		System.out.println("Green light");
	}

	@Override
	public void change() {
		System.out.println("Changes to red light");
	}

}

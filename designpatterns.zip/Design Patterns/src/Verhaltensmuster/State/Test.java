package Verhaltensmuster.State;

public class Test {

	public static void main(String[] args) {
		Light light = new Light();
		light.blink();
		light.change();
		light.blink();
		light.change();
		light.blink();
		light.change();
		light.blink();
	}

}

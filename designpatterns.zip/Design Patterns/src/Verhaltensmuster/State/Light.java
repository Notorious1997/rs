package Verhaltensmuster.State;

public class Light {
	private State state;
	private GreenLight greenLight;
	private RedLight redLight;

	public Light() {
		greenLight = new GreenLight(this);
		redLight = new RedLight(this);
		
		state = greenLight;
	}
	
	public void blink(){
		state.blink();
	}
	
	public void change(){

		state.change();
		if(state == greenLight){
			state = redLight;
		} else {
			state = greenLight;
		}
	
	}
	
}

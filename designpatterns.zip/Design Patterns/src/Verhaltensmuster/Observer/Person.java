package Verhaltensmuster.Observer;

public class Person implements NewsLetterObserver {
	private String name;
	private NewsLetter currentNewsLetter;
	
	public Person(String name){
		this.name = name;
	}

	@Override
	public void update(NewsLetter newsletter) {
		currentNewsLetter = newsletter;
		System.out.println(name + " has the new newsletter: " + currentNewsLetter.getTopic());
	}
}

package Verhaltensmuster.Observer;

public class SportNewsLetter extends NewsLetterSubject {
	private NewsLetter currentNewsLetter;
	
	public SportNewsLetter(NewsLetter currentNewsLetter) {
		this.currentNewsLetter = currentNewsLetter;
	}


	public NewsLetter getCurrentNewsLetter(){
		return currentNewsLetter;
	}
	
	
	public void setCurrentNewsLetter(NewsLetter newsletter){
		this.currentNewsLetter = newsletter;
		System.out.println("New newsletter has arrived");
		this.sendNewsLetter(currentNewsLetter);
	}
}

package Verhaltensmuster.Observer;

public class Test {
	public static void main(String[] args) {
		SportNewsLetter sn = new SportNewsLetter(new NewsLetter("WM 2018", "Topic"));
		
		Person person1 = new Person("1");
		Person person2 = new Person("2");
		Person person3 = new Person("3");
		
		sn.subscribe(person1);
		sn.subscribe(person2);
		sn.subscribe(person3);
		
		sn.setCurrentNewsLetter(new NewsLetter("Runescape", "Jad"));
	}
}

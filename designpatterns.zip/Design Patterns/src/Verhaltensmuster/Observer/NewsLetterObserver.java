package Verhaltensmuster.Observer;

public interface NewsLetterObserver {
	public void update(NewsLetter newsletter);
	
}

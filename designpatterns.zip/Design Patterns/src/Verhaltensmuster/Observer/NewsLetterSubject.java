package Verhaltensmuster.Observer;

import java.util.ArrayList;

public class NewsLetterSubject {
	private ArrayList<NewsLetterObserver> observers = new ArrayList<>();
	
	public void subscribe(NewsLetterObserver observer){
		if(!observers.contains(observer)){
			observers.add(observer);
		}
	}
	
	public void unsubscribe(NewsLetterObserver observer){
		if(observers.contains(observer)){
			observers.remove(observer);
		}
	}
	
	public void sendNewsLetter(NewsLetter newsletter){
		for(NewsLetterObserver o : observers){
			o.update(newsletter);
		}
	}
}

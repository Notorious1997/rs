package Verhaltensmuster.IteratorPattern;

public class Test {
	public static void main(String[] args) {
		ChannelCollection radio = new CarRadio();
		radio.addChannel(new Channel("Channel 1", 101.1));
		radio.addChannel(new Channel("Channel 2", 84.3));
		radio.addChannel(new Channel("Channel 3", 99.9));
		
		ChannelIterator iterator = radio.createIterator("shuffles");
		while(iterator.hasNext()){
			Channel c = iterator.next();
			System.out.println(c);
		}
	}
}

package Verhaltensmuster.TemplateMethod;

public class PoliceOfficerWorkday extends WorkdayPlanner {

	@Override
	public void goToWork() {
		System.out.println("Goes to police station");
	}

	@Override
	public void work() {
		System.out.println("Handcuffing criminals");
	}

	@Override
	public boolean isHoliday() {
		// TODO Auto-generated method stub
		return false;
	}

}

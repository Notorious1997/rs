package Verhaltensmuster.TemplateMethod;

public class ManagerWorkday extends WorkdayPlanner {

	@Override
	public void goToWork() {
		System.out.println("Walking to the office");
	}

	@Override
	public void work() {
		System.out.println("Manager work");
	}

	@Override
	public boolean isHoliday() {
		return true;
	}
	
}

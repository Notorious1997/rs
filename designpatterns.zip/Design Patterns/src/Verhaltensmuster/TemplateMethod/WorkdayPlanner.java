package Verhaltensmuster.TemplateMethod;

public abstract class WorkdayPlanner {
	
	public void createWorkdayPlan(){
		wakeUp();
		takeShower();
		breakfast();
		if(!isHoliday()){
			goToWork();
			work();
		}
		
		sleep();
	}
	
	public abstract boolean isHoliday();
	
	public abstract void goToWork();
	public abstract void work();
	
	public void wakeUp(){
		System.out.println("Wakes up and walking to the bathroom");
	}
	
	public void takeShower(){
		System.out.println("Taking a shower");
	}
	
	public void breakfast(){
		System.out.println("Breakfast");
	}
	
	public void sleep(){
		System.out.println("Going to bed");
	}
}

package Verhaltensmuster.TemplateMethod;

public class Test {

	public static void main(String[] args) {
		WorkdayPlanner managerDay = new ManagerWorkday();
		
		WorkdayPlanner policeOfficerDay = new PoliceOfficerWorkday();
		
		managerDay.createWorkdayPlan();
		
		policeOfficerDay.createWorkdayPlan();
	}

}

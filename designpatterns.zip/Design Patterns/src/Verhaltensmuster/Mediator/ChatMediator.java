package Verhaltensmuster.Mediator;

public interface ChatMediator {
	public void broadcastMessage(String message, User user);
	public void addUser(User user);
	public void sendMessage(String message, User user);
}

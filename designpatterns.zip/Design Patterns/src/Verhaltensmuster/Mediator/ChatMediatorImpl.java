package Verhaltensmuster.Mediator;

import java.util.ArrayList;

public class ChatMediatorImpl implements ChatMediator {
	private ArrayList<User> userList = new ArrayList<>();

	public ChatMediatorImpl() {
		this.userList = new ArrayList<User>();
	}

	@Override
	public void broadcastMessage(String message, User user) {
		for(User u: userList){
			if(u != user){
				u.receive(message);
			}
		}
	}

	@Override
	public void sendMessage(String message, User user) {
		user.receive(message);
	}
	

	@Override
	public void addUser(User user) {
		this.userList.add(user);
	}
}

package Verhaltensmuster.Mediator;

public class UserImpl extends User{

	public UserImpl(ChatMediator mediator, String name) {
		super(mediator, name);
	}

	@Override
	public void sendToAll(String message) {
		System.out.println(this.name + ": " + message);
		mediator.broadcastMessage(message, this);
	}
	
	

	@Override
	public void receive(String message) {
		System.out.println(this.name + " has received a new message: " + message);
	}

	@Override
	public void sendToUser(String message, User user) {
		System.out.println(this.name + " has sent a message to: " + user.name);
		mediator.sendMessage(message, user);
	}

}

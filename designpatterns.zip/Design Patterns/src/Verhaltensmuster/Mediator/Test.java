package Verhaltensmuster.Mediator;

public class Test {

	public static void main(String[] args) {
		ChatMediator chat = new ChatMediatorImpl();
		User user1 = new UserImpl(chat, "User 1");
		User user2 = new UserImpl(chat, "User 2");
		User user3 = new UserImpl(chat, "User 3");
		User user4 = new UserImpl(chat, "User 4");
		
		chat.addUser(user1);
		chat.addUser(user2);
		chat.addUser(user3);
		chat.addUser(user4);
		
		ChatMediator chat2 = new ChatMediatorImpl();
		User user5 = new UserImpl(chat2, "User 5");
		User user6 = new UserImpl(chat2, "User 6");
		User user7 = new UserImpl(chat2, "User 7");
		User user8 = new UserImpl(chat2, "User 8");
		
		chat2.addUser(user5);
		chat2.addUser(user6);
		chat2.addUser(user7);
		chat2.addUser(user8);
		
		user1.sendToAll("hello");
		user5.sendToAll("how are you?");
		
		user1.sendToUser("hello", user2);
	}

}

package Verhaltensmuster.Mediator;

public abstract class User {
	ChatMediator mediator;
	String name;
	
	public User(ChatMediator mediator, String name){
		this.mediator = mediator;
		this.name = name;
	}
	
	public abstract void sendToAll(String message);
	public abstract void receive(String message);
	public abstract void sendToUser(String message, User user);
}

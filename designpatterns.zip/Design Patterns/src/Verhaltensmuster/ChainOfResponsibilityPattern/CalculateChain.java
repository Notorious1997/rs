package Verhaltensmuster.ChainOfResponsibilityPattern;

public interface CalculateChain {
	public void setNextChain(CalculateChain nextChain);
	
	public void calculate(Numbers request);
}

package Verhaltensmuster.Strategy;

public interface CalculateStrategy {
	int calculate(int number1, int number2);
}

package Verhaltensmuster.Strategy;

public class Test {

	public static void main(String[] args) {
		Calculator calc = new Calculator();
		
		calc.setCs(new AddStrategy());
		System.out.println(calc.calculate(1, 2));
		calc.setCs(new SubtractStrategy());
		System.out.println(calc.calculate(1, 2));
	}

}

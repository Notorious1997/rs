package Verhaltensmuster.Strategy;

public class MultiplyStrategy implements CalculateStrategy{

	@Override
	public int calculate(int number1, int number2) {
		return number1 * number2;
	}
	
}

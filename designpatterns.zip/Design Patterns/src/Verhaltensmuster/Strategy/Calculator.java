package Verhaltensmuster.Strategy;

public class Calculator {
	CalculateStrategy cs;


	public void setCs(CalculateStrategy cs) {
		this.cs = cs;
	}
	
	public int calculate(int number1, int number2){
		return cs.calculate(number1, number2);
	}
}

package Player;

public abstract class Level {
	int level;
	
	public void increaseLevel(){
		level++;
	}

}

package Player;

public class CombatLevel extends Level {
	int combatLevel;

	CombatLevel() {
		this.combatLevel = 3;
	}

	public int getCombatLevel() {
		return combatLevel;
	}
	
	public void increaseCombatLevel(){
		combatLevel++;
	}
	

	public static void showCombatLevel() {
		System.out.println("Current combat level: " + Player.getInstance().combatLevel.getCombatLevel());
	}

}

package Player;

import Items.Item;

public class Inventory {
	public int filledSlots = 0;
	public int inventoryLength = 2;
	public int[] quantity = new int[inventoryLength];
	public Item[] items = new Item[inventoryLength];

	public void addItem(Item item) {

		int counter = 0;
		while (counter < inventoryLength - 1 & items[counter] != null) {
			if (items[counter].getName().equals(item.getName())) {
				// quantity[counter] += item.getQuantity();
				items[counter].setQuantity(quantity[counter] + item.getQuantity());
				// TODO FIX DUPLICATE ITEMS
				return;
			}
			counter++;

		}
		items[counter] = item;
		quantity[counter] = item.getQuantity();
		filledSlots++;
		System.out.println("TEST" + filledSlots);
	}

	public void ShowInventory() {
		boolean isEmpty = true;
		System.out.println("You have the following item(s) in your inventory: ");
		for (int i = 0; i < inventoryLength; i++) {
			if (items[i] != null) {
				isEmpty = false;
				System.out.println(items[i].toString());
			}
		}
		if (isEmpty) {
			System.out.println("None");
		}
	}
	
	public static void showInventory(){
		Player.getInstance().inv.ShowInventory();
	}

}

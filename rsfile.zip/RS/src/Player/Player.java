package Player;

import Equipment.Equipment;
import Locations.Location;

public class Player {
	private static final Player instance = new Player("Notorious");
	public String name;
	
	public Location location;
	public CombatLevel combatLevel;
	public TotalLevel totalLevel;	
	public Inventory inv;
	public Equipment eq; 
	
	private Player(String type) {
		this.name = type;
		this.combatLevel = new CombatLevel();
		this.totalLevel = new TotalLevel();
		this.location = new Location();
		inv = new Inventory();
		eq = new Equipment();
	}
	
	public static Player getInstance(){
		return instance;
	}

	@Override
	public String toString() {
		return name + ", level: " + Player.getInstance().combatLevel.getCombatLevel() + ", Total level: " + Player.getInstance().totalLevel.getTotalLevel();
	}
	
	
}

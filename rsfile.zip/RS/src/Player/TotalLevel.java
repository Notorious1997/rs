package Player;

public class TotalLevel extends Level {
	int totalLevel;
	
	

	TotalLevel() {
		this.totalLevel = 31;
	}
	

	TotalLevel(int totalLevel) {
		this.totalLevel = totalLevel;
	}



	public int getTotalLevel() {
		return totalLevel;
	}

	public void setTotalLevel(int totalLevel) {
		this.totalLevel = totalLevel;
	}
	
	public void increaseTotalLevel(){
		totalLevel++;
	}
	
	public static void showTotalLevel() {
		System.out.println("Current total level: " + Player.getInstance().totalLevel.getTotalLevel());
	}
}

package GameManager;

public interface MyCommands {
	void execute();
}

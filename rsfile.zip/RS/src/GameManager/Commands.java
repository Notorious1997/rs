package GameManager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

import Equipment.Equipment;
import Items.Item;
import Map.Map;
import Player.CombatLevel;
import Player.Inventory;
import Player.Player;
import Player.TotalLevel;

public class Commands implements MyCommands {

	public static void main(String[] args) {
		HashMap<String, Commands> commands = new HashMap<>();
		commands.put("test", new Commands());

		Commands command = commands.get("test");
		command.execute();

	}

	static void showCommands() {
		ArrayList<String> commands = new ArrayList<>();

		System.out.println("You can enter the following commands: " + "\nCommands: Lists your commands. "
				+ "\nInventory: Opens up your inventory" + "\nEquipment: Let's you equip your items"
				+ "\nSpawnItem: Spawns a random item in your inventory" + "\nTravel: Travels your character"
				+ "\nLocate: Locates your character" + "\nClose: Exits the game");

	}

	static void TEST() {
		System.out.println("Test123456");
	}

	@Override
	public void execute() {
		TEST();
	}

	static void useCommands() {
		HashMap<String, Runnable> commands = new HashMap<>();
		commands.put("test", () -> showCommands());

		String input = "";
		Scanner sc = new Scanner(System.in);
		while (!input.equals("Close")) {
			input = sc.next();
			switch (input) {
			case "commands":
				showCommands();
				break;
			case "combatlevel":
				CombatLevel.showCombatLevel();
				break;
			case "totatlevel":
				TotalLevel.showTotalLevel();
				break;
			case "inventory":
				Inventory.showInventory();
				break;
			case "equipment":
				Equipment.showEquipment();
				break;
			case "equip":
				break;
			case "spawnitem":
				Item.spawnItem();
				break;
			case "travel":
				Map.travel();
				break;
			case "increaselevel":
				Player.getInstance().combatLevel.increaseCombatLevel();
				break;
			case "locate":
				Map.locate();
				break;
			case "close":
				sc.close();
				System.exit(0);
				break;
			}
		}
	}

}

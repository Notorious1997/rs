package GameManager;

import Map.Map;
import Player.Player;


public class Game {

	static void startGame() {
		System.out.println(Player.getInstance().toString() + " has spawned \nType 'commands' to see your options");
		Map.initializeMap();
		Commands.useCommands();
	}

}

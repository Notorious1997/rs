package Map;

import java.util.ArrayList;
import Locations.Location;
import Player.Player;

public class Map {
	ArrayList<Location> locations = new ArrayList<>();

	public Map(ArrayList<Location> locations) {
		this.locations = locations;
	}
	
	public static Map initializeMap() {
		ArrayList<Location> locations = new ArrayList<>();
		Map map = new Map(locations);

		Location lumbridge = new Location("Lumbridge", false);
		Location varrock = new Location("Varrock", true);

		locations.add(lumbridge);
		locations.add(varrock);
		
		return map;
	}

	public void showLocations(){
		for (Location loc : locations){
			System.out.println(loc.getName());
		}
	}
	
	public static void travel() {
		System.out.println("Where would you like to travel?");
		Map map = Map.initializeMap();
		
		map.showLocations();
	}
	
	public static void locate(){
		System.out.println("Your character is in: " + Player.getInstance().location.getName());
	}

}

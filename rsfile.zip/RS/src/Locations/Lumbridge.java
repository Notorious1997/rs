package Locations;

public final class Lumbridge extends Location{
	
}

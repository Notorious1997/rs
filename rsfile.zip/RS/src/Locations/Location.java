package Locations;

public class Location {
	String name;
	boolean monsters;

	
	public Location(String name, boolean monsters) {
		this.name = name;
		this.monsters = monsters;
	}


	public Location() {
		name = "Lumbridge";
	}


	public String getName() {
		return name;
	}


	public boolean isMonsters() {
		return monsters;
	}

	
	
	
	

}

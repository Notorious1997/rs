package Skills;

public class Attack extends Skills {
	
}

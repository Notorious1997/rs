package Skills;

public abstract class Skills {
	String name;
	int level;
	int experience;
	
	void increaseLevel(){
		level++;
	}
}

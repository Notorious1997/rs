package Enemy;

import Items.DropTable;

public class Cow extends Enemy {
	
	
	protected Cow(DropTable dropTable, int hitpoints, int dps) {
		super(dropTable, hitpoints, dps);
	}
	
}

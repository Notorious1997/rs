package Enemy;

import Items.DropTable;

public abstract class Enemy {
	DropTable dropTable;
	
	int hitpoints;
	int dps;
	
	protected Enemy(DropTable dropTable, int hitpoints, int dps) {
		this.dropTable = dropTable;
		this.hitpoints = hitpoints;
		this.dps = dps;
	}
	
	
}

package Items;

import java.util.ArrayList;

public class DropTable {
	ArrayList<Item> drops = new ArrayList<>();
}

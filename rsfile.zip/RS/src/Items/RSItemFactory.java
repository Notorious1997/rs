package Items;

import Equipment.Weapon;

public class RSItemFactory extends ItemFactory{
	
	@Override
	public Item createItem(int id) {
		Item item = null;
		if(id == 1){
			item = new Weapon(5, "Bronze dagger", 10, 100, true);
		} else {
			item = new Weapon(1, "Sword", 10, 100, true);
			System.out.println("Error");
		}
		return item;
	}


}

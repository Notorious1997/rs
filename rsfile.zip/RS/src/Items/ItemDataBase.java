package Items;
import java.util.HashMap;

public class ItemDataBase {
	/*
	static HashMap<String, Integer> map = new HashMap<String, Integer>();
	String name;
	int alchemyWorth;
	
	public static void main(String[] args) {
		map.put("Iron dagger", 100);
	}
	*/
}

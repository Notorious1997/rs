package Items;

public abstract class ItemFactory {
	
	public abstract Item createItem(int id);
	
	public Item generateRandomItem() {
		int randomValue = 1;
		return createItem(randomValue);
	}
}

package Items;

import Equipment.Weapon;
import Player.Player;

public abstract class Item {
	String name;
	final int alchemyWorth;
	int quantity;
	final boolean equipable;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAlchemyWorth() {
		return alchemyWorth;
	}

	public Item(int quantity, String name, int alchemyWorth, boolean equipable) {
		this.name = name;
		this.alchemyWorth = alchemyWorth;
		this.quantity = quantity;
		this.equipable = equipable;
	}

	public static void spawnItem() {
		RSItemFactory factory = new RSItemFactory();
		Item item = factory.generateRandomItem();
		if (Player.getInstance().inv.filledSlots < Player.getInstance().inv.inventoryLength) {
			Player.getInstance().inv.addItem(item);
			System.out.println("The following item has been added to your inventory: " + item.toString());
		} else {
			System.out.println("You have no space left in your inventory");
		}
		
	}

	public boolean isEquipable() {
		return equipable;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	@Override
	public String toString() {
		return quantity + "x " + name;
	}

	protected abstract void useItem();

	public void Equip(Item item) {
		Player.getInstance().eq.setWeapon((Weapon) item);
	}
}

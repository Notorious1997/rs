package Equipment;

public class Boots {

}

package Equipment;

public class Cape {

}

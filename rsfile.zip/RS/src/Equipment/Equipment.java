package Equipment;

import Player.Player;

public class Equipment {
	Weapon weapon;

	public Weapon getWeapon() {
		return weapon;
	}

	public void setWeapon(Weapon weapon) {
		this.weapon = weapon;
	}
	
	public String toString(){
		return "The following equipment is equipped: " + getWeapon(); 
	}
	
	public static void showEquipment(){
		Player.getInstance().eq.toString();
	}
}

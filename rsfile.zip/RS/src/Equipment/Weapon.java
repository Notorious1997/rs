package Equipment;

import Items.Item;

public class Weapon extends Item{
	int attackDamage;
	

	public Weapon(int quantity, String name, int attackDamage, int alchemyWorth, boolean equipable) {
		super(quantity, name, alchemyWorth, equipable);
		this.attackDamage = attackDamage;
	}

	protected void useItem() {
		System.out.println("Equips Sword");
	}
	
	

	

}

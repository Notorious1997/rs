package Equipment;

public class Amulet {

}

package Equipment;

public class Ring {

}

package Equipment;

public class Torso {

}

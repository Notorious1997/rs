package Equipment;

public class Gloves {

}

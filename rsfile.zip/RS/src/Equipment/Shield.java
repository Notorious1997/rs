package Equipment;

public class Shield {

}

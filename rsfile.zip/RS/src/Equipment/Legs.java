package Equipment;

public class Legs {

}
